#!/bin/bash
dotnet build jenkins-plugin-model/src/Pi.Web/Pi.Web.csproj