﻿namespace Pi.Runtime
{
    public enum RunMode
    {
        Web,
        Console,
        File
    }
}
